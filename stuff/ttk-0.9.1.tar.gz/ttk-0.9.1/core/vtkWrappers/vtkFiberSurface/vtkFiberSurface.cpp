#include                  <vtkFiberSurface.h>

vtkStandardNewMacro(vtkFiberSurface)

vtkFiberSurface::vtkFiberSurface(){

  UseAllCores = false;
  RangeCoordinates = false;
  EdgeParameterization = false;
  EdgeIds = false;
  TetIds = false;
  CaseIds = false;
  PointMerge = false;
  RangeOctree = false;
  PointMergeDistanceThreshold = 0.000001;
  SetNumberOfInputPorts(2);
}

vtkFiberSurface::~vtkFiberSurface(){
}

int vtkFiberSurface::doIt(vector<vtkDataSet *> &inputs,
  vector<vtkDataSet *> &outputs){
  
  Memory m;
  Timer t;
  
  vtkDataSet *input = inputs[0];
  vtkUnstructuredGrid *polygon = vtkUnstructuredGrid::SafeDownCast(inputs[1]);
  vtkPolyData *output = vtkPolyData::SafeDownCast(outputs[0]);
  
  vtkDataArray  *dataUfield = NULL, *dataVfield = NULL,
                *polygonUfield = NULL, *polygonVfield = NULL;
          
  if(DataUcomponent.length()){
    dataUfield = input->GetPointData()->GetArray(DataUcomponent.data());
  }
  else{
    // default
    dataUfield = input->GetPointData()->GetArray(0);
  }
  if(!dataUfield){
    stringstream msg;
    msg << "[vtkFiberSurface] Error1: Could not find data array '"
      << DataUcomponent << "'!" << endl;
    dMsg(cerr, msg.str(), fatalMsg);
    return -1;
  }
  
  if(DataVcomponent.length()){
    dataVfield = input->GetPointData()->GetArray(DataVcomponent.data());
  }
  else{
    // default
    dataVfield = input->GetPointData()->GetArray(0);
  }
  if(!dataVfield){
    stringstream msg;
    msg << "[vtkFiberSurface] Error2: Could not find data array '"
      << DataVcomponent << "'!" << endl;
    dMsg(cerr, msg.str(), fatalMsg);
    return -2;
  }
  
  if(PolygonUcomponent.length()){
    polygonUfield = polygon->GetPointData()->GetArray(PolygonUcomponent.data());
  }
  else{
    // default
    polygonUfield = polygon->GetPointData()->GetArray(0);
  }
  if(!polygonUfield){
    stringstream msg;
    msg << "[vtkFiberSurface] Error3: Could not find data array '"
      << PolygonUcomponent << "'!" << endl;
    dMsg(cerr, msg.str(), fatalMsg);
    return -3;
  }
  
  if(PolygonVcomponent.length()){
    polygonVfield = polygon->GetPointData()->GetArray(PolygonVcomponent.data());
  }
  else{
    // default
    polygonVfield = polygon->GetPointData()->GetArray(0);
  }
  if(!polygonVfield){
    stringstream msg;
    msg << "[vtkFiberSurface] Error4: Could not find data array '"
      << PolygonVcomponent << "'!" << endl;
    dMsg(cerr, msg.str(), fatalMsg);
    return -4;
  }
 
  if(!((input->GetDataObjectType() == VTK_UNSTRUCTURED_GRID)
    ||(input->GetDataObjectType() == TTK_UNSTRUCTURED_GRID)
    ||(input->GetDataObjectType() == VTK_IMAGE_DATA)
    ||(input->GetDataObjectType() == TTK_IMAGE_DATA))){
    stringstream msg;
    msg << "[vtkFiberSurface] Error5: Unsupported VTK data-structure ("
      << input->GetDataObjectType() << ")" << endl;
    dMsg(cerr, msg.str(), fatalMsg);
    return -5;
  }
  
  Triangulation *triangulation = vtkTriangulation::getTriangulation(input);
  
  if(!triangulation)
    return -1;
  triangulation->setWrapper(this);
  fiberSurface_.setupTriangulation(triangulation);
  fiberSurface_.setWrapper(this);
  outputVertexList_.clear();
  fiberSurface_.setGlobalVertexList(&outputVertexList_);
  fiberSurface_.setInputField(
    dataUfield->GetVoidPointer(0),
    dataVfield->GetVoidPointer(0));
  fiberSurface_.setPolygonEdgeNumber(polygon->GetNumberOfCells());
  threadedTriangleList_.resize(polygon->GetNumberOfCells());
  threadedVertexList_.resize(polygon->GetNumberOfCells());
  fiberSurface_.setPolygon(&inputPolygon_);
 
  fiberSurface_.setPointMerging(PointMerge);
  fiberSurface_.setPointMergingThreshold(PointMergeDistanceThreshold);
  
#ifdef withrangeDrivenOctree
  if((!RangeOctree)
    ||(dataUfield->GetMTime() > GetMTime())
    ||(dataVfield->GetMTime() > GetMTime())){
    
    {
      stringstream msg;
      msg << "[vtkFiberSurface] Resetting octree..." << endl;
      dMsg(cout, msg.str(), infoMsg);
    }
    
    fiberSurface_.flushOctree();
    Modified();
  }
#endif
  
  inputPolygon_.clear();
  
  const long long int *cellArray = polygon->GetCells()->GetPointer();
  int cellNumber = polygon->GetNumberOfCells();

  int vertexId0, vertexId1;
  pair<pair<double, double>, pair<double, double> > rangeEdge;

  for(int i = 0; i < cellNumber; i++){

    vertexId0 = cellArray[3*i + 1];
    vertexId1 = cellArray[3*i + 2];
    
    rangeEdge.first.first = polygonUfield->GetTuple1(vertexId0);
    rangeEdge.first.second = polygonVfield->GetTuple1(vertexId0);
    
    rangeEdge.second.first = polygonUfield->GetTuple1(vertexId1);
    rangeEdge.second.second = polygonVfield->GetTuple1(vertexId1);
    
    inputPolygon_.push_back(rangeEdge);
  }
  
  for(int i = 0; i < (int) threadedTriangleList_.size(); i++){
    threadedTriangleList_[i].clear();
    fiberSurface_.setTriangleList(i, &(threadedTriangleList_[i]));
    threadedVertexList_[i].clear();
    fiberSurface_.setVertexList(i, &(threadedVertexList_[i]));
  }
  
  switch(dataUfield->GetDataType()){
    
    case VTK_CHAR:
      
      switch(dataVfield->GetDataType()){
        vtkTemplateMacro((
          {
#ifdef withrangeDrivenOctree
            if(RangeOctree)
              fiberSurface_.buildOctree<char, VTK_TT>();
#endif
            fiberSurface_.computeSurface<char, VTK_TT>();
          }
        ));
      }
      
      break;
    
    case VTK_DOUBLE:
      
      switch(dataVfield->GetDataType()){
        vtkTemplateMacro((
          {
#ifdef withrangeDrivenOctree
            if(RangeOctree)
              fiberSurface_.buildOctree<double, VTK_TT>();
#endif
            fiberSurface_.computeSurface<double, VTK_TT>();
          }
        ));
      }
      
      break;
      
    case VTK_FLOAT:
      
      switch(dataVfield->GetDataType()){
        vtkTemplateMacro((
          {
#ifdef withrangeDrivenOctree
            if(RangeOctree)
              fiberSurface_.buildOctree<float, VTK_TT>();
#endif
            fiberSurface_.computeSurface<float, VTK_TT>();
          }
        ));
      }
      
      break;
      
    case VTK_INT:
      
      switch(dataVfield->GetDataType()){
        vtkTemplateMacro((
          {
#ifdef withrangeDrivenOctree
            if(RangeOctree)
              fiberSurface_.buildOctree<int, VTK_TT>();
#endif
            fiberSurface_.computeSurface<int, VTK_TT>();
          }
        ));
      }
      
      break;
      
    case VTK_UNSIGNED_CHAR:
      
      switch(dataVfield->GetDataType()){
        vtkTemplateMacro((
          {
#ifdef withrangeDrivenOctree
            if(RangeOctree)
              fiberSurface_.buildOctree<unsigned char, VTK_TT>();
#endif
            fiberSurface_.computeSurface<unsigned char, VTK_TT>();
          }
        ));
      }
      
      break;
      
    case VTK_UNSIGNED_SHORT:
      
      switch(dataVfield->GetDataType()){
        vtkTemplateMacro((
          {
#ifdef withrangeDrivenOctree
            if(RangeOctree)
              fiberSurface_.buildOctree<unsigned short, VTK_TT>();
#endif
            fiberSurface_.computeSurface<unsigned short, VTK_TT>();
          }
        ));
      }
      
      break;
  }
  
  // prepare the VTK output
  // NOTE: right now, there is a copy of the output data. this is no good.
  // to fix.
  
  int triangleNumber = 0;
  
  for(int i = 0; i < (int) threadedTriangleList_.size(); i++){
    triangleNumber += threadedTriangleList_[i].size();
  }
  
  vtkSmartPointer<vtkPoints> outputVertexList = 
    vtkSmartPointer<vtkPoints>::New();
  vtkSmartPointer<vtkDoubleArray> outputU = 
    vtkSmartPointer<vtkDoubleArray>::New();
  vtkSmartPointer<vtkDoubleArray> outputV = 
    vtkSmartPointer<vtkDoubleArray>::New();
  vtkSmartPointer<vtkDoubleArray> outputParameterization = 
    vtkSmartPointer<vtkDoubleArray>::New();
  vtkSmartPointer<vtkCellArray> outputTriangleList = 
    vtkSmartPointer<vtkCellArray>::New();
  vtkSmartPointer<vtkIntArray> outputEdgeIds = 
    vtkSmartPointer<vtkIntArray>::New();
  vtkSmartPointer<vtkIntArray> outputTetIds = 
    vtkSmartPointer<vtkIntArray>::New();
  vtkSmartPointer<vtkIntArray> outputCaseIds = 
    vtkSmartPointer<vtkIntArray>::New();
    
  if(RangeCoordinates){
    outputU->SetName(DataUcomponent.data());
    outputU->SetNumberOfTuples(outputVertexList_.size());
    
    outputV->SetName(DataVcomponent.data());
    outputV->SetNumberOfTuples(outputVertexList_.size());
  }
  
  if(EdgeParameterization){
    outputParameterization->SetName("EdgeParameterization");
    outputParameterization->SetNumberOfTuples(outputVertexList_.size());
  }
  
  outputVertexList->SetNumberOfPoints(outputVertexList_.size());
  output->SetPoints(outputVertexList);
  
#ifdef withOpenMP
#pragma omp parallel for num_threads(threadNumber_)
#endif
  for(int i = 0; i < (int) outputVertexList_.size(); i++){
    outputVertexList->SetPoint(i, 
      outputVertexList_[i].p_[0], 
      outputVertexList_[i].p_[1], 
      outputVertexList_[i].p_[2]);
    if(RangeCoordinates){
      outputU->SetTuple1(i, outputVertexList_[i].uv_.first);
      outputV->SetTuple1(i, outputVertexList_[i].uv_.second);
    }
    if(EdgeParameterization){
      outputParameterization->SetTuple1(i, outputVertexList_[i].t_);
    }
  }
  if(RangeCoordinates){
    output->GetPointData()->AddArray(outputU);
    output->GetPointData()->AddArray(outputV);
  }
  else{
    output->GetPointData()->RemoveArray(DataUcomponent.data());
    output->GetPointData()->RemoveArray(DataVcomponent.data());
  }
  if(EdgeParameterization){
    output->GetPointData()->AddArray(outputParameterization);
  }
  else{
    output->GetPointData()->RemoveArray("EdgeParameterization");
  }
  
  if(EdgeIds){
    outputEdgeIds->SetName("EdgeIds");
    outputEdgeIds->SetNumberOfTuples(triangleNumber);
  }
 
  if(TetIds){
    outputTetIds->SetName("TetIds");
    outputTetIds->SetNumberOfTuples(triangleNumber);
  }
 
  if(CaseIds){
    outputCaseIds->SetName("CaseIds");
    outputCaseIds->SetNumberOfTuples(triangleNumber);
  }
  
  vtkSmartPointer<vtkIdList> idList = vtkSmartPointer<vtkIdList>::New();
  idList->SetNumberOfIds(3);
  
  triangleNumber = 0;
  for(int i = 0; i < (int) threadedTriangleList_.size(); i++){
    for(int j = 0; j < (int) threadedTriangleList_[i].size(); j++){
      for(int k = 0; k < 3; k++){
        idList->SetId(k, threadedTriangleList_[i][j].vertexIds_[k]);
      }
      outputTriangleList->InsertNextCell(idList);
      if(EdgeIds){
        outputEdgeIds->SetTuple1(triangleNumber, i);
      }
      if(TetIds){
        outputTetIds->SetTuple1(triangleNumber, 
          threadedTriangleList_[i][j].tetId_);
      }
      if(CaseIds){
        outputCaseIds->SetTuple1(triangleNumber,
          threadedTriangleList_[i][j].caseId_);
      }
      triangleNumber++;
    }
  }
  output->SetPolys(outputTriangleList);
  if(EdgeIds){
    output->GetCellData()->AddArray(outputEdgeIds);
  }
  else{
    output->GetCellData()->RemoveArray("EdgeIds");
  }
  if(TetIds){
    output->GetCellData()->AddArray(outputTetIds);
  }
  else{
    output->GetCellData()->RemoveArray("TetIds");
  }
  if(CaseIds){
    output->GetCellData()->AddArray(outputCaseIds);
  }
  else{
    output->GetCellData()->RemoveArray("CaseIds");
  }
  
  {
    stringstream msg;
    msg << "[vtkFiberSurface] Memory usage: " << m.getElapsedUsage() 
      << " MB." << endl;
    dMsg(cout, msg.str(), memoryMsg);
  }
  
  return 0;
}
