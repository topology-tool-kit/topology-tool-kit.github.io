#include                  <MorseSmaleComplex.h>

MorseSmaleComplex::MorseSmaleComplex():
  AbstractMorseSmaleComplex(),
  abstractMorseSmaleComplex_{}
{
}

MorseSmaleComplex::~MorseSmaleComplex(){
}

