#include                  <ScalarFieldSmoother.h>

ScalarFieldSmoother::ScalarFieldSmoother(){

  inputData_ = NULL;
  outputData_ = NULL;
  dimensionNumber_ = 1;
  triangulation_ = NULL;
}

ScalarFieldSmoother::~ScalarFieldSmoother(){
  
}



