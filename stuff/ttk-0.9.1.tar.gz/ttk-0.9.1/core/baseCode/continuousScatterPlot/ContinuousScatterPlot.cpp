#include                  <ContinuousScatterPlot.h>

ContinuousScatterPlot::ContinuousScatterPlot():
  vertexNumber_{},
  triangulation_{},
  withDummyValue_{},
  dummyValue_{},
  resolutions_{},
  inputScalarField1_{},
  inputScalarField2_{},
  scalarMin_{},
  scalarMax_{},
  density_{}
{}

ContinuousScatterPlot::~ContinuousScatterPlot(){
}

