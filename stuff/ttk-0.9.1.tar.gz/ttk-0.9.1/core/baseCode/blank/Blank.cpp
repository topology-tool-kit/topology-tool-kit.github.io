#include                  <Blank.h>

Blank::Blank(){

  inputData_ = NULL;
  outputData_ = NULL;
  triangulation_ = NULL;
}

Blank::~Blank(){
  
}

