
from paraview.simple import *
from paraview import coprocessing

#--------------------------------------------------------------
# This part of the code loads TTK's plugins. 
# Topology Toolkit version 0.9.2
#--------------------------------------------------------------
import glob
import os
from os.path import join as ttk_path_join
ttk_plugins_path = "/usr/local/lib/paraview-5.4/plugins/"
for x in glob.glob(ttk_path_join(
                ttk_plugins_path,'*.so' if os.name=='posix' else '*.dll')):
        LoadPlugin(x, ns=globals())

#--------------------------------------------------------------
# Code generated from cpstate.py to create the CoProcessor.
# ParaView 5.4.0 64 bits

#--------------------------------------------------------------
# Global screenshot output options
imageFileNamePadding=0
rescale_lookuptable=False


# ----------------------- CoProcessor definition -----------------------

def CreateCoProcessor():
  def _CreatePipeline(coprocessor, datadescription):
    class Pipeline:
      # state file generated using paraview version 5.4.0

      # ----------------------------------------------------------------
      # setup views used in the visualization
      # ----------------------------------------------------------------

      #### disable automatic camera reset on 'Show'
      paraview.simple._DisableFirstRenderCameraReset()

      # Create a new 'Line Chart View'
      lineChartView1 = CreateView('XYChartView')
      lineChartView1.ViewSize = [427, 406]
      lineChartView1.LegendPosition = [226, 268]
      lineChartView1.LeftAxisLogScale = 1
      lineChartView1.LeftAxisRangeMinimum = 1.0
      lineChartView1.LeftAxisRangeMaximum = 10.0
      lineChartView1.BottomAxisLogScale = 1
      lineChartView1.BottomAxisRangeMinimum = 1e-15
      lineChartView1.BottomAxisRangeMaximum = 100000.0
      lineChartView1.RightAxisRangeMaximum = 6.66
      lineChartView1.TopAxisRangeMaximum = 6.66

      # register the view with coprocessor
      # and provide it with information such as the filename to use,
      # how frequently to write the images, etc.
      coprocessor.RegisterView(lineChartView1,
          filename='persistenceCurve_%t.png', freq=1, fittoscreen=1, magnification=1, width=427, height=406, cinema={})
      lineChartView1.ViewTime = datadescription.GetTime()

      # Create a new 'Render View'
      renderView1 = CreateView('RenderView')
      renderView1.ViewSize = [298, 841]
      renderView1.AxesGrid = 'GridAxes3DActor'
      renderView1.OrientationAxesVisibility = 0
      renderView1.CenterOfRotation = [-0.199999999254942, 1.5, 0.5]
      renderView1.StereoType = 0
      renderView1.CameraPosition = [-0.171068517136871, 1.57232870529518, 6.654504388566]
      renderView1.CameraFocalPoint = [-0.171068517136871, 1.57232870529518, 0.5]
      renderView1.CameraParallelScale = 3.51113692714491
      renderView1.Background = [0.32, 0.34, 0.43]

      # register the view with coprocessor
      # and provide it with information such as the filename to use,
      # how frequently to write the images, etc.
      coprocessor.RegisterView(renderView1,
          filename='flatDomain_%t.png', freq=1, fittoscreen=0, magnification=1, width=298, height=841, cinema={})
      renderView1.ViewTime = datadescription.GetTime()

      # Create a new 'Render View'
      renderView2 = CreateView('RenderView')
      renderView2.ViewSize = [768, 841]
      renderView2.AxesGrid = 'GridAxes3DActor'
      renderView2.OrientationAxesVisibility = 0
      renderView2.CenterOfRotation = [-0.199999999254942, 1.5, 0.632491111755371]
      renderView2.StereoType = 0
      renderView2.CameraPosition = [-2.60419911860865, -1.24202746110969, 3.9156658788845]
      renderView2.CameraFocalPoint = [0.0369586240350484, 1.32385071075222, 0.686331144020101]
      renderView2.CameraViewUp = [0.26275584817170405, 0.6391901474744242, 0.7227692021822681]
      renderView2.CameraParallelScale = 1.53383644987404
      renderView2.Background = [0.32, 0.34, 0.43]

      # register the view with coprocessor
      # and provide it with information such as the filename to use,
      # how frequently to write the images, etc.
      coprocessor.RegisterView(renderView2,
          filename='warpedDomain_%t.png', freq=1, fittoscreen=0, magnification=1, width=768, height=841, cinema={})
      renderView2.ViewTime = datadescription.GetTime()

      # Create a new 'Render View'
      renderView3 = CreateView('RenderView')
      renderView3.ViewSize = [427, 405]
      renderView3.AxesGrid = 'GridAxes3DActor'
      renderView3.OrientationAxesVisibility = 0
      renderView3.CenterOfRotation = [124.578765869141, 132.491111755371, 0.0]
      renderView3.StereoType = 0
      renderView3.CameraPosition = [124.578765869141, 132.491111755371, 593.439779663859]
      renderView3.CameraFocalPoint = [124.578765869141, 132.491111755371, 0.0]
      renderView3.CameraParallelScale = 153.59351709845
      renderView3.Background = [0.32, 0.34, 0.43]

      # register the view with coprocessor
      # and provide it with information such as the filename to use,
      # how frequently to write the images, etc.
      coprocessor.RegisterView(renderView3,
          filename='persistenceDiagram_%t.png', freq=1, fittoscreen=1, magnification=1, width=427, height=405, cinema={})
      renderView3.ViewTime = datadescription.GetTime()

      # ----------------------------------------------------------------
      # setup the data processing pipelines
      # ----------------------------------------------------------------

      # create a new 'EnSight Reader'
      # create a producer from a simulation input
      rESULTS_ENSIGHTcase = coprocessor.CreateProducer(datadescription, 'input')

      # create a new 'Extract Block'
      extractFluidDomain = ExtractBlock(Input=rESULTS_ENSIGHTcase)
      extractFluidDomain.BlockIndices = [1]

      # create a new 'Slice'
      slice1 = Slice(Input=extractFluidDomain)
      slice1.SliceType = 'Plane'
      slice1.SliceOffsetValues = [0.0]

      # init the 'Plane' selected for 'SliceType'
      slice1.SliceType.Origin = [-0.199999999254942, 1.5, 0.5]
      slice1.SliceType.Normal = [0.0, 0.0, 1.0]

      # create a new 'Merge Blocks'
      mergeBlocks1 = MergeBlocks(Input=slice1)

      # create a new 'Cell Data to Point Data'
      cellDatatoPointData1 = CellDatatoPointData(Input=mergeBlocks1)

      # create a new 'TTK PersistenceCurve'
      tTKPersistenceCurve1 = TTKPersistenceCurve(Input=cellDatatoPointData1)
      tTKPersistenceCurve1.ScalarField = 'TempC'
      tTKPersistenceCurve1.InputOffsetField = ''

      # create a new 'TTK PersistenceDiagram'
      tTKPersistenceDiagram1 = TTKPersistenceDiagram(Input=cellDatatoPointData1)
      tTKPersistenceDiagram1.ScalarField = 'TempC'
      tTKPersistenceDiagram1.InputOffsetField = ''

      # create a new 'Threshold'
      diag = Threshold(Input=tTKPersistenceDiagram1)
      diag.Scalars = ['CELLS', 'PairIdentifier']
      diag.ThresholdRange = [-1.0, -1.0]

      # create a new 'Extract Surface'
      extractSurface2 = ExtractSurface(Input=diag)

      # create a new 'Parallel UnstructuredGrid Writer'
      parallelUnstructuredGridWriter1 = servermanager.writers.XMLPUnstructuredGridWriter(Input=tTKPersistenceDiagram1)

      # register the writer with coprocessor
      # and provide it with information such as the filename to use,
      # how frequently to write the data, etc.
      coprocessor.RegisterWriter(parallelUnstructuredGridWriter1, filename='ttk_persistenceDiagram_%t.pvtu', freq=10, paddingamount=0)

      # create a new 'Threshold'
      nonDiag = Threshold(Input=tTKPersistenceDiagram1)
      nonDiag.Scalars = ['CELLS', 'PairIdentifier']
      nonDiag.ThresholdRange = [0.0, 6.0]

      # create a new 'Threshold'
      persistenceThreshold = Threshold(Input=nonDiag)
      persistenceThreshold.Scalars = ['CELLS', 'Persistence']
      persistenceThreshold.ThresholdRange = [0.0001, 1000.0]

      # create a new 'Extract Surface'
      extractSurface1 = ExtractSurface(Input=persistenceThreshold)

      # create a new 'TTK TopologicalSimplification'
      tTKTopologicalSimplification1 = TTKTopologicalSimplification(Domain=cellDatatoPointData1,
          Constraints=persistenceThreshold)
      tTKTopologicalSimplification1.ScalarField = 'TempC'
      tTKTopologicalSimplification1.InputOffsetField = ''

      # create a new 'Warp By Scalar'
      warpByScalar1 = WarpByScalar(Input=tTKTopologicalSimplification1)
      warpByScalar1.Scalars = ['POINTS', 'TempC']
      warpByScalar1.ScaleFactor = 0.001

      # create a new 'TTK ScalarFieldCriticalPoints'
      tTKScalarFieldCriticalPoints2 = TTKScalarFieldCriticalPoints(Input=warpByScalar1)
      tTKScalarFieldCriticalPoints2.ScalarField = 'TempC'
      tTKScalarFieldCriticalPoints2.UseInputOffsetField = 1

      # create a new 'TTK SphereFromPoint'
      tTKSphereFromPoint3 = TTKSphereFromPoint(Input=tTKScalarFieldCriticalPoints2)
      tTKSphereFromPoint3.Radius = 0.05

      # create a new 'TTK ScalarFieldCriticalPoints'
      tTKScalarFieldCriticalPoints1 = TTKScalarFieldCriticalPoints(Input=tTKTopologicalSimplification1)
      tTKScalarFieldCriticalPoints1.ScalarField = 'TempC'
      tTKScalarFieldCriticalPoints1.UseInputOffsetField = 1

      # create a new 'TTK SphereFromPoint'
      tTKSphereFromPoint2 = TTKSphereFromPoint(Input=tTKScalarFieldCriticalPoints1)
      tTKSphereFromPoint2.Radius = 0.05

      # ----------------------------------------------------------------
      # setup color maps and opacity mapes used in the visualization
      # note: the Get..() functions create a new object, if needed
      # ----------------------------------------------------------------

      # get color transfer function/color map for 'TempC'
      tempCLUT = GetColorTransferFunction('TempC')
      tempCLUT.RGBPoints = [20.0, 0.0, 0.129412, 0.584314, 168.315979003907, 0.917647, 0.941176, 0.788235, 316.631958007812, 0.0, 0.431373, 0.0]
      tempCLUT.ColorSpace = 'RGB'
      tempCLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'TempC'
      tempCPWF = GetOpacityTransferFunction('TempC')
      tempCPWF.Points = [20.0, 0.0, 0.5, 0.0, 316.631958007812, 1.0, 0.5, 0.0]
      tempCPWF.ScalarRangeInitialized = 1

      # get color transfer function/color map for 'NodeType'
      nodeTypeLUT = GetColorTransferFunction('NodeType')
      nodeTypeLUT.RGBPoints = [0.0, 0.0, 0.129412, 0.584314, 1.5, 0.917647, 0.941176, 0.788235, 3.0, 0.0, 0.431373, 0.0]
      nodeTypeLUT.ColorSpace = 'RGB'
      nodeTypeLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'NodeType'
      nodeTypePWF = GetOpacityTransferFunction('NodeType')
      nodeTypePWF.Points = [0.0, 0.0, 0.5, 0.0, 3.0, 1.0, 0.5, 0.0]
      nodeTypePWF.ScalarRangeInitialized = 1

      # get color transfer function/color map for 'CriticalType'
      criticalTypeLUT = GetColorTransferFunction('CriticalType')
      criticalTypeLUT.RGBPoints = [0.0, 0.0, 0.129412, 0.584314, 1.0, 0.917647, 0.941176, 0.788235, 2.0, 0.0, 0.431373, 0.0]
      criticalTypeLUT.ColorSpace = 'RGB'
      criticalTypeLUT.ScalarRangeInitialized = 1.0

      # get opacity transfer function/opacity map for 'CriticalType'
      criticalTypePWF = GetOpacityTransferFunction('CriticalType')
      criticalTypePWF.Points = [0.0, 0.0, 0.5, 0.0, 2.0, 1.0, 0.5, 0.0]
      criticalTypePWF.ScalarRangeInitialized = 1

      # ----------------------------------------------------------------
      # setup the visualization in view 'lineChartView1'
      # ----------------------------------------------------------------

      # find source
      tTKPersistenceCurve1_1 = FindSource('TTKPersistenceCurve1')

      # show data from tTKPersistenceCurve1_1
      tTKPersistenceCurve1Display = Show(OutputPort(tTKPersistenceCurve1, 3), lineChartView1)
      # trace defaults for the display properties.
      tTKPersistenceCurve1Display.CompositeDataSetIndex = [0]
      tTKPersistenceCurve1Display.AttributeType = 'Row Data'
      tTKPersistenceCurve1Display.UseIndexForXAxis = 0
      tTKPersistenceCurve1Display.XArrayName = 'Persistence (all pairs)'
      tTKPersistenceCurve1Display.SeriesVisibility = ['Number Of Pairs (all pairs)']
      tTKPersistenceCurve1Display.SeriesLabel = ['Number Of Pairs (all pairs)', 'Number Of Pairs (all pairs)', 'Persistence (all pairs)', 'Persistence (all pairs)']
      tTKPersistenceCurve1Display.SeriesColor = ['Number Of Pairs (all pairs)', '0', '0', '0.498039', 'Persistence (all pairs)', '0.889998', '0.100008', '0.110002']
      tTKPersistenceCurve1Display.SeriesPlotCorner = ['Number Of Pairs (all pairs)', '0', 'Persistence (all pairs)', '0']
      tTKPersistenceCurve1Display.SeriesLabelPrefix = ''
      tTKPersistenceCurve1Display.SeriesLineStyle = ['Number Of Pairs (all pairs)', '1', 'Persistence (all pairs)', '1']
      tTKPersistenceCurve1Display.SeriesLineThickness = ['Number Of Pairs (all pairs)', '2', 'Persistence (all pairs)', '2']
      tTKPersistenceCurve1Display.SeriesMarkerStyle = ['Number Of Pairs (all pairs)', '0', 'Persistence (all pairs)', '0']

      # ----------------------------------------------------------------
      # setup the visualization in view 'renderView1'
      # ----------------------------------------------------------------

      # show data from tTKTopologicalSimplification1
      tTKTopologicalSimplification1Display = Show(tTKTopologicalSimplification1, renderView1)
      # trace defaults for the display properties.
      tTKTopologicalSimplification1Display.Representation = 'Surface'
      tTKTopologicalSimplification1Display.ColorArrayName = ['POINTS', 'TempC']
      tTKTopologicalSimplification1Display.LookupTable = tempCLUT
      tTKTopologicalSimplification1Display.Specular = 1.0
      tTKTopologicalSimplification1Display.OSPRayScaleArray = 'Pressure'
      tTKTopologicalSimplification1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      tTKTopologicalSimplification1Display.SelectOrientationVectors = 'Velocity'
      tTKTopologicalSimplification1Display.ScaleFactor = 0.3
      tTKTopologicalSimplification1Display.SelectScaleArray = 'Pressure'
      tTKTopologicalSimplification1Display.GlyphType = 'Arrow'
      tTKTopologicalSimplification1Display.GlyphTableIndexArray = 'Pressure'
      tTKTopologicalSimplification1Display.DataAxesGrid = 'GridAxesRepresentation'
      tTKTopologicalSimplification1Display.PolarAxes = 'PolarAxesRepresentation'
      tTKTopologicalSimplification1Display.ScalarOpacityFunction = tempCPWF
      tTKTopologicalSimplification1Display.ScalarOpacityUnitDistance = 0.273481894149741
      tTKTopologicalSimplification1Display.GaussianRadius = 0.15
      tTKTopologicalSimplification1Display.SetScaleArray = ['POINTS', 'Pressure']
      tTKTopologicalSimplification1Display.ScaleTransferFunction = 'PiecewiseFunction'
      tTKTopologicalSimplification1Display.OpacityArray = ['POINTS', 'Pressure']
      tTKTopologicalSimplification1Display.OpacityTransferFunction = 'PiecewiseFunction'

      # show data from tTKSphereFromPoint2
      tTKSphereFromPoint2Display = Show(tTKSphereFromPoint2, renderView1)
      # trace defaults for the display properties.
      tTKSphereFromPoint2Display.Representation = 'Surface'
      tTKSphereFromPoint2Display.ColorArrayName = ['POINTS', 'Critical Type']
      tTKSphereFromPoint2Display.LookupTable = criticalTypeLUT
      tTKSphereFromPoint2Display.Specular = 1.0
      tTKSphereFromPoint2Display.OSPRayScaleArray = 'Critical Type'
      tTKSphereFromPoint2Display.OSPRayScaleFunction = 'PiecewiseFunction'
      tTKSphereFromPoint2Display.SelectOrientationVectors = 'None'
      tTKSphereFromPoint2Display.ScaleFactor = 0.693633806705475
      tTKSphereFromPoint2Display.SelectScaleArray = 'None'
      tTKSphereFromPoint2Display.GlyphType = 'Arrow'
      tTKSphereFromPoint2Display.GlyphTableIndexArray = 'None'
      tTKSphereFromPoint2Display.DataAxesGrid = 'GridAxesRepresentation'
      tTKSphereFromPoint2Display.PolarAxes = 'PolarAxesRepresentation'
      tTKSphereFromPoint2Display.GaussianRadius = 0.346816903352737
      tTKSphereFromPoint2Display.SetScaleArray = ['POINTS', 'Critical Type']
      tTKSphereFromPoint2Display.ScaleTransferFunction = 'PiecewiseFunction'
      tTKSphereFromPoint2Display.OpacityArray = ['POINTS', 'Critical Type']
      tTKSphereFromPoint2Display.OpacityTransferFunction = 'PiecewiseFunction'

      # ----------------------------------------------------------------
      # setup the visualization in view 'renderView2'
      # ----------------------------------------------------------------

      # show data from warpByScalar1
      warpByScalar1Display = Show(warpByScalar1, renderView2)
      # trace defaults for the display properties.
      warpByScalar1Display.Representation = 'Surface'
      warpByScalar1Display.ColorArrayName = ['POINTS', 'TempC']
      warpByScalar1Display.LookupTable = tempCLUT
      warpByScalar1Display.Specular = 1.0
      warpByScalar1Display.OSPRayScaleArray = 'Pressure'
      warpByScalar1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      warpByScalar1Display.SelectOrientationVectors = 'Velocity'
      warpByScalar1Display.ScaleFactor = 29.2199666261673
      warpByScalar1Display.SelectScaleArray = 'Pressure'
      warpByScalar1Display.GlyphType = 'Arrow'
      warpByScalar1Display.GlyphTableIndexArray = 'Pressure'
      warpByScalar1Display.DataAxesGrid = 'GridAxesRepresentation'
      warpByScalar1Display.PolarAxes = 'PolarAxesRepresentation'
      warpByScalar1Display.ScalarOpacityFunction = tempCPWF
      warpByScalar1Display.ScalarOpacityUnitDistance = 26.1212631390146
      warpByScalar1Display.GaussianRadius = 14.6099833130836
      warpByScalar1Display.SetScaleArray = ['POINTS', 'Pressure']
      warpByScalar1Display.ScaleTransferFunction = 'PiecewiseFunction'
      warpByScalar1Display.OpacityArray = ['POINTS', 'Pressure']
      warpByScalar1Display.OpacityTransferFunction = 'PiecewiseFunction'

      # show data from tTKSphereFromPoint3
      tTKSphereFromPoint3Display = Show(tTKSphereFromPoint3, renderView2)
      # trace defaults for the display properties.
      tTKSphereFromPoint3Display.Representation = 'Surface'
      tTKSphereFromPoint3Display.ColorArrayName = ['POINTS', 'Critical Type']
      tTKSphereFromPoint3Display.LookupTable = criticalTypeLUT
      tTKSphereFromPoint3Display.Specular = 1.0
      tTKSphereFromPoint3Display.OSPRayScaleArray = 'Critical Type'
      tTKSphereFromPoint3Display.OSPRayScaleFunction = 'PiecewiseFunction'
      tTKSphereFromPoint3Display.SelectOrientationVectors = 'Critical Type'
      tTKSphereFromPoint3Display.ScaleFactor = 0.698633778095245
      tTKSphereFromPoint3Display.SelectScaleArray = 'Critical Type'
      tTKSphereFromPoint3Display.GlyphType = 'Arrow'
      tTKSphereFromPoint3Display.GlyphTableIndexArray = 'Critical Type'
      tTKSphereFromPoint3Display.DataAxesGrid = 'GridAxesRepresentation'
      tTKSphereFromPoint3Display.PolarAxes = 'PolarAxesRepresentation'
      tTKSphereFromPoint3Display.GaussianRadius = 0.349316889047623
      tTKSphereFromPoint3Display.SetScaleArray = ['POINTS', 'Critical Type']
      tTKSphereFromPoint3Display.ScaleTransferFunction = 'PiecewiseFunction'
      tTKSphereFromPoint3Display.OpacityArray = ['POINTS', 'Critical Type']
      tTKSphereFromPoint3Display.OpacityTransferFunction = 'PiecewiseFunction'

      # ----------------------------------------------------------------
      # setup the visualization in view 'renderView3'
      # ----------------------------------------------------------------

      # show data from persistenceThreshold
      persistenceThresholdDisplay = Show(persistenceThreshold, renderView3)
      # trace defaults for the display properties.
      persistenceThresholdDisplay.Representation = 'Points'
      persistenceThresholdDisplay.ColorArrayName = ['POINTS', 'NodeType']
      persistenceThresholdDisplay.LookupTable = nodeTypeLUT
      persistenceThresholdDisplay.PointSize = 15.0
      persistenceThresholdDisplay.Specular = 1.0
      persistenceThresholdDisplay.OSPRayScaleArray = 'NodeType'
      persistenceThresholdDisplay.OSPRayScaleFunction = 'PiecewiseFunction'
      persistenceThresholdDisplay.SelectOrientationVectors = 'NodeType'
      persistenceThresholdDisplay.ScaleFactor = 22.4982223510742
      persistenceThresholdDisplay.SelectScaleArray = 'NodeType'
      persistenceThresholdDisplay.GlyphType = 'Arrow'
      persistenceThresholdDisplay.GlyphTableIndexArray = 'NodeType'
      persistenceThresholdDisplay.DataAxesGrid = 'GridAxesRepresentation'
      persistenceThresholdDisplay.PolarAxes = 'PolarAxesRepresentation'
      persistenceThresholdDisplay.ScalarOpacityFunction = nodeTypePWF
      persistenceThresholdDisplay.ScalarOpacityUnitDistance = 160.584466897391
      persistenceThresholdDisplay.GaussianRadius = 11.2491111755371
      persistenceThresholdDisplay.SetScaleArray = ['POINTS', 'NodeType']
      persistenceThresholdDisplay.ScaleTransferFunction = 'PiecewiseFunction'
      persistenceThresholdDisplay.OpacityArray = ['POINTS', 'NodeType']
      persistenceThresholdDisplay.OpacityTransferFunction = 'PiecewiseFunction'

      # show data from extractSurface1
      extractSurface1Display = Show(extractSurface1, renderView3)
      # trace defaults for the display properties.
      extractSurface1Display.Representation = 'Surface'
      extractSurface1Display.ColorArrayName = ['POINTS', '']
      extractSurface1Display.PointSize = 1.0
      extractSurface1Display.LineWidth = 3.0
      extractSurface1Display.Specular = 1.0
      extractSurface1Display.OSPRayScaleArray = 'NodeType'
      extractSurface1Display.OSPRayScaleFunction = 'PiecewiseFunction'
      extractSurface1Display.SelectOrientationVectors = 'NodeType'
      extractSurface1Display.ScaleFactor = 22.4982223510742
      extractSurface1Display.SelectScaleArray = 'NodeType'
      extractSurface1Display.GlyphType = 'Arrow'
      extractSurface1Display.GlyphTableIndexArray = 'NodeType'
      extractSurface1Display.DataAxesGrid = 'GridAxesRepresentation'
      extractSurface1Display.PolarAxes = 'PolarAxesRepresentation'
      extractSurface1Display.GaussianRadius = 11.2491111755371
      extractSurface1Display.SetScaleArray = ['POINTS', 'NodeType']
      extractSurface1Display.ScaleTransferFunction = 'PiecewiseFunction'
      extractSurface1Display.OpacityArray = ['POINTS', 'NodeType']
      extractSurface1Display.OpacityTransferFunction = 'PiecewiseFunction'

      # show data from extractSurface2
      extractSurface2Display = Show(extractSurface2, renderView3)
      # trace defaults for the display properties.
      extractSurface2Display.Representation = 'Surface'
      extractSurface2Display.ColorArrayName = [None, '']
      extractSurface2Display.DiffuseColor = [0.0, 0.0, 0.0]
      extractSurface2Display.LineWidth = 3.0
      extractSurface2Display.Specular = 1.0
      extractSurface2Display.OSPRayScaleArray = 'NodeType'
      extractSurface2Display.OSPRayScaleFunction = 'PiecewiseFunction'
      extractSurface2Display.SelectOrientationVectors = 'NodeType'
      extractSurface2Display.ScaleFactor = 20.9157531738281
      extractSurface2Display.SelectScaleArray = 'NodeType'
      extractSurface2Display.GlyphType = 'Arrow'
      extractSurface2Display.GlyphTableIndexArray = 'NodeType'
      extractSurface2Display.DataAxesGrid = 'GridAxesRepresentation'
      extractSurface2Display.PolarAxes = 'PolarAxesRepresentation'
      extractSurface2Display.GaussianRadius = 10.4578765869141
      extractSurface2Display.SetScaleArray = ['POINTS', 'NodeType']
      extractSurface2Display.ScaleTransferFunction = 'PiecewiseFunction'
      extractSurface2Display.OpacityArray = ['POINTS', 'NodeType']
      extractSurface2Display.OpacityTransferFunction = 'PiecewiseFunction'

      # ----------------------------------------------------------------
      # finally, restore active source
      SetActiveSource(parallelUnstructuredGridWriter1)
      # ----------------------------------------------------------------
    return Pipeline()

  class CoProcessor(coprocessing.CoProcessor):
    def CreatePipeline(self, datadescription):
      self.Pipeline = _CreatePipeline(self, datadescription)

  coprocessor = CoProcessor()
  # these are the frequencies at which the coprocessor updates.
  freqs = {'input': [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 10]}
  coprocessor.SetUpdateFrequencies(freqs)
  return coprocessor


#--------------------------------------------------------------
# Global variable that will hold the pipeline for each timestep
# Creating the CoProcessor object, doesn't actually create the ParaView pipeline.
# It will be automatically setup when coprocessor.UpdateProducers() is called the
# first time.
coprocessor = CreateCoProcessor()

#--------------------------------------------------------------
# Enable Live-Visualizaton with ParaView and the update frequency
coprocessor.EnableLiveVisualization(False, 1)

# ---------------------- Data Selection method ----------------------

def RequestDataDescription(datadescription):
    "Callback to populate the request for current timestep"
    global coprocessor
    if datadescription.GetForceOutput() == True:
        # We are just going to request all fields and meshes from the simulation
        # code/adaptor.
        for i in range(datadescription.GetNumberOfInputDescriptions()):
            datadescription.GetInputDescription(i).AllFieldsOn()
            datadescription.GetInputDescription(i).GenerateMeshOn()
        return

    # setup requests for all inputs based on the requirements of the
    # pipeline.
    coprocessor.LoadRequestedData(datadescription)

# ------------------------ Processing method ------------------------

def DoCoProcessing(datadescription):
    "Callback to do co-processing for current timestep"
    global coprocessor

    # Update the coprocessor by providing it the newly generated simulation data.
    # If the pipeline hasn't been setup yet, this will setup the pipeline.
    coprocessor.UpdateProducers(datadescription)

    # Write output data, if appropriate.
    coprocessor.WriteData(datadescription);

    # Write image capture (Last arg: rescale lookup table), if appropriate.
    coprocessor.WriteImages(datadescription, rescale_lookuptable=rescale_lookuptable,
        image_quality=0, padding_amount=imageFileNamePadding)

    # Live Visualization, if enabled.
    coprocessor.DoLiveVisualization(datadescription, "localhost", 22222)
