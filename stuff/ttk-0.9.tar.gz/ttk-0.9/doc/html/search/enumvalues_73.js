var searchData=
[
  ['saddle1',['Saddle1',['../namespacettk.html#a6a672131b6adc95a7ff49637de99746da356def59d909cbfb4697a8072846c887',1,'ttk::Saddle1()'],['../namespacettk.html#a4e039213c04e857ce0a088bce1427645a356def59d909cbfb4697a8072846c887',1,'ttk::Saddle1()']]],
  ['saddle1_5farc',['Saddle1_arc',['../namespacettk.html#ad40656c69a5a3c7056f031a65aff8968aee93cb3c64ba9d96e3850a5f64c62847',1,'ttk']]],
  ['saddle1_5fsaddle2_5farc',['Saddle1_saddle2_arc',['../namespacettk.html#ad40656c69a5a3c7056f031a65aff8968a683347d8d01be0ca48566f9658f29387',1,'ttk']]],
  ['saddle2',['Saddle2',['../namespacettk.html#a6a672131b6adc95a7ff49637de99746dabee5ecb53314499c0c2ee972351b157a',1,'ttk::Saddle2()'],['../namespacettk.html#a4e039213c04e857ce0a088bce1427645abee5ecb53314499c0c2ee972351b157a',1,'ttk::Saddle2()']]],
  ['saddle2_5farc',['Saddle2_arc',['../namespacettk.html#ad40656c69a5a3c7056f031a65aff8968a9252560ff1b1dc3fd862d585bc958b42',1,'ttk']]],
  ['span',['Span',['../namespacettk.html#a1360a5a461439fada7dd2767cc04bd47afbf1c3d93b4494a5fa2cbffbd875b4f7',1,'ttk']]],
  ['split',['Split',['../namespacettk.html#a60443d899c41fc5a7cf104700b6ed8dbaaa6819cd4ffd9901b6287b2435a892c2',1,'ttk']]],
  ['splitsaddle',['SplitSaddle',['../classttk_1_1MandatoryCriticalPoints.html#ab2cf29184e67a40532222ae2a99a2a0ea3c2c5ec8d5dfd4ece3d7adb3aeafd649',1,'ttk::MandatoryCriticalPoints']]],
  ['splittree',['SplitTree',['../classttk_1_1MandatoryCriticalPoints.html#a0e7a766f9a884eadac1826a65ad6f4dda1577f90fbc4e514ca5a8fbbb9bfc92ab',1,'ttk::MandatoryCriticalPoints']]]
];
