var searchData=
[
  ['query',['query',['../classttk_1_1LowestCommonAncestor.html#a701a7dc5dbc16075f0a6cbcad9397dc2',1,'ttk::LowestCommonAncestor::query()'],['../classttk_1_1RangeMinimumQuery.html#a7e2540fbf2362f377324b89a6163dac7',1,'ttk::RangeMinimumQuery::query()']]]
];
