var searchData=
[
  ['local_5fmaximum',['Local_maximum',['../namespacettk.html#a6a672131b6adc95a7ff49637de99746daefbcd967ae50908baf330d056bbae37e',1,'ttk::Local_maximum()'],['../namespacettk.html#a4e039213c04e857ce0a088bce1427645aefbcd967ae50908baf330d056bbae37e',1,'ttk::Local_maximum()']]],
  ['local_5fminimum',['Local_minimum',['../namespacettk.html#a6a672131b6adc95a7ff49637de99746da2e7e012b7d4f76c7b9ae6bcd005e0240',1,'ttk::Local_minimum()'],['../namespacettk.html#a4e039213c04e857ce0a088bce1427645a2e7e012b7d4f76c7b9ae6bcd005e0240',1,'ttk::Local_minimum()']]]
];
