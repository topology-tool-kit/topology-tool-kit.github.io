var searchData=
[
  ['print_5ferror',['PRINT_ERROR',['../DiscreteGradient_8h.html#aa0004d1735f5c5a47cd385525c5bdbc0',1,'DiscreteGradient.h']]],
  ['proto_5fversion',['PROTO_VERSION',['../DiscreteGradient_8h.html#ad34386a1c00776bdbabb91bad0d66caa',1,'DiscreteGradient.h']]]
];
