var searchData=
[
  ['simplificationcriterion',['SimplificationCriterion',['../classttk_1_1ReebSpace.html#aabfa2a3992fe0b2b1ad851588eb1b1ba',1,'ttk::ReebSpace']]],
  ['simplifmethod',['SimplifMethod',['../namespacettk.html#a1360a5a461439fada7dd2767cc04bd47',1,'ttk']]]
];
