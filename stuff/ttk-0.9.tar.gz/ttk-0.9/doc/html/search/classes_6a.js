var searchData=
[
  ['jacobiset',['JacobiSet',['../classttk_1_1JacobiSet.html',1,'ttk']]]
];
