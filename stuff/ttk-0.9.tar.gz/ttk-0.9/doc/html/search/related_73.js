var searchData=
[
  ['sublevelsettree',['SubLevelSetTree',['../classttk_1_1SuperArc.html#aa62216218fb1f3074213d37df00f3d76',1,'ttk::SuperArc::SubLevelSetTree()'],['../classttk_1_1Node.html#aa62216218fb1f3074213d37df00f3d76',1,'ttk::Node::SubLevelSetTree()'],['../classttk_1_1ContourTreeSimplificationMetric.html#aa62216218fb1f3074213d37df00f3d76',1,'ttk::ContourTreeSimplificationMetric::SubLevelSetTree()']]]
];
