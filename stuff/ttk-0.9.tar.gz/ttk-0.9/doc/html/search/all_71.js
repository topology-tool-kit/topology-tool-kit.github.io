var searchData=
[
  ['query',['query',['../classttk_1_1LowestCommonAncestor.html#a701a7dc5dbc16075f0a6cbcad9397dc2',1,'ttk::LowestCommonAncestor::query()'],['../classttk_1_1RangeMinimumQuery.html#a7e2540fbf2362f377324b89a6163dac7',1,'ttk::RangeMinimumQuery::query()']]],
  ['queryresultnumber_5f',['queryResultNumber_',['../classttk_1_1RangeDrivenOctree.html#afced61f4894847e36ff81e12f95868d6',1,'ttk::RangeDrivenOctree']]]
];
