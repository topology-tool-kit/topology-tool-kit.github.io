var searchData=
[
  ['persist',['Persist',['../namespacettk.html#a1360a5a461439fada7dd2767cc04bd47ae01b7da3eea35110f6c910ee68595775',1,'ttk']]],
  ['pruned',['Pruned',['../namespacettk.html#a99656e357617bcc0d896b87e085c9ac3ad74021f649961af5b8fde4df3922596f',1,'ttk']]]
];
