var searchData=
[
  ['real',['real',['../namespacettk.html#a867286284f66b3e34281a3443526b99a',1,'ttk']]]
];
