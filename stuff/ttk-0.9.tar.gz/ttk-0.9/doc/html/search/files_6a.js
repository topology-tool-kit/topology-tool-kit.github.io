var searchData=
[
  ['jacobiset_2ecpp',['JacobiSet.cpp',['../JacobiSet_8cpp.html',1,'']]],
  ['jacobiset_2eh',['JacobiSet.h',['../JacobiSet_8h.html',1,'']]]
];
