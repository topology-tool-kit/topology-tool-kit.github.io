var searchData=
[
  ['rangedrivenoctree',['RangeDrivenOctree',['../classttk_1_1RangeDrivenOctree.html',1,'ttk']]],
  ['rangeminimumquery',['RangeMinimumQuery',['../classttk_1_1RangeMinimumQuery.html',1,'ttk']]],
  ['rangeminimumquery_3c_20int_20_3e',['RangeMinimumQuery&lt; int &gt;',['../classttk_1_1RangeMinimumQuery.html',1,'ttk']]],
  ['reebspace',['ReebSpace',['../classttk_1_1ReebSpace.html',1,'ttk']]],
  ['reebspacedata',['ReebSpaceData',['../classttk_1_1ReebSpace_1_1ReebSpaceData.html',1,'ttk::ReebSpace']]],
  ['region',['Region',['../structttk_1_1Region.html',1,'ttk']]]
];
